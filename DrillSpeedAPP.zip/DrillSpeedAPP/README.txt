Application for velocity prediction using KNN and LSTM Classifiers.
To install open MATLAB and double click on the file *DrillSpeedClassifier.mlappinstall*.
Follow instructions on screen.